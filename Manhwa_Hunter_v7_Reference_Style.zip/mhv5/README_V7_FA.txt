Manhwa Hunter v7
- Pagination for search results: 20 items per page.
- Reading progress is saved locally per title using Android SharedPreferences.
- Search shortcuts include the user's preferred Persian sites in this order: مانسیت، مانهوا تاور، مانگیت، مانگا آپ، بوک خان، مانهوا چی، مانگاریوم، مانگا باز.
- Since exact official URLs for those names have not yet been confirmed, each shortcut currently performs a web search for that site's name plus the manga title instead of guessing a domain.
- Real manga cover images are loaded from AniList when internet access is available.
Build: gradle -p mhv5 assembleDebug (workflow included under mhv5/.github/workflows/)
