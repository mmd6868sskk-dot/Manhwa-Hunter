package com.manhwahunter.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import android.text.TextUtils
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 10, 20)
    private val card = Color.rgb(17, 23, 42)
    private var accent = Color.rgb(139, 67, 255)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private lateinit var nameInput: EditText
    private lateinit var storyInput: EditText
    private lateinit var resultsBox: LinearLayout
    private val selectedGenres = linkedSetOf<String>()
    private val worker = Executors.newFixedThreadPool(4)
    private val genres = listOf("اکشن", "فانتزی", "ماجراجویی", "سیستمی", "تناسخی", "عاشقانه", "کمدی", "ترسناک", "مدرسه‌ای", "هنرهای رزمی", "دانش‌آموزی", "درام")
    private val genreButtons = mutableMapOf<String, TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 16, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun text(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun params(bottom: Int = 10) = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom) }

    private fun base(title: String) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(16), dp(12), dp(16), dp(12)) }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        val back = text("‹", 34f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(dp(8),0,dp(16),0); setOnClickListener { showHome() } }
        top.addView(back, LinearLayout.LayoutParams(dp(40), dp(48)))
        top.addView(text(title, 21f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        val crown = text("♛", 28f, accent, true).apply { gravity = Gravity.CENTER }
        top.addView(crown, LinearLayout.LayoutParams(dp(42), dp(48)))
        root.addView(top, params(8))
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0,0,0,dp(18)) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showHome() {
        base("MANHWA HUNTER")
        val hero = ImageView(this).apply {
            setImageResource(com.manhwahunter.app.R.drawable.anime_banner)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(card, 22, accent)
            clipToOutline = true
        }
        content.addView(hero, LinearLayout.LayoutParams(-1, dp(185)).apply { bottomMargin = dp(12) })
        content.addView(text("شکارچی مانهوا؛ دنیای داستان‌های جدید", 16f, Color.rgb(205,195,235), true), params(14))

        nameInput = input("اسم مانهوا را بنویس…")
        content.addView(nameInput, params(8))
        storyInput = input("توضیح داستان (اختیاری)")
        content.addView(storyInput, params(12))

        content.addView(text("ژانرها  •  برای انتخاب، روی ژانر نگه دار", 15f, Color.WHITE, true), params(8))
        genreButtons.clear()
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        genres.chunked(3).forEach { rowItems ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowItems.forEach { g ->
                val b = text("✦  $g", 13f, Color.rgb(220,220,240), true).apply {
                    gravity = Gravity.CENTER; setPadding(dp(4), dp(12), dp(4), dp(12)); background = rounded(card, 15, Color.rgb(50,55,85))
                    setOnClickListener { status.text = "برای انتخاب یا لغو «$g»، انگشتت را روی دکمه نگه دار." }
                    setOnLongClickListener { if (selectedGenres.contains(g)) selectedGenres.remove(g) else selectedGenres.add(g); updateGenreButtons(); status.text = if (selectedGenres.isEmpty()) "ژانری انتخاب نشده." else "ژانرهای انتخاب‌شده: ${selectedGenres.joinToString("، ")}"; true }
                }
                genreButtons[g] = b
                row.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            grid.addView(row, params(2))
        }
        content.addView(grid, params(10))

        val search = actionButton("⌕   پیدا کردن مانهواها") { searchManga() }
        content.addView(search, params(8))
        val theme = actionButton("◐   تغییر رنگ برنامه") { cycleTheme() }
        content.addView(theme, params(12))
        status = text("نتایج با تصویر جلد داخل برنامه نمایش داده می‌شوند؛ برای دیدن لینک‌های بیشتر از جست‌وجوی داخلی استفاده کن.", 13f, Color.rgb(180,190,215)).apply { setPadding(dp(12),dp(12),dp(12),dp(12)); background = rounded(card, 14) }
        content.addView(status, params(8))
    }

    private fun updateGenreButtons() {
        genreButtons.forEach { (g, b) ->
            val chosen = selectedGenres.contains(g)
            b.text = (if (chosen) "✓  " else "✦  ") + g
            b.setTextColor(if (chosen) Color.WHITE else Color.rgb(220,220,240))
            b.background = rounded(if (chosen) accent else card, 15, if (chosen) Color.rgb(205,150,255) else Color.rgb(50,55,85))
        }
    }

    private fun input(hintText: String) = EditText(this).apply {
        hint = hintText; textSize = 15f; setTextColor(Color.WHITE); setHintTextColor(Color.rgb(135,145,170)); setPadding(dp(14), dp(12), dp(14), dp(12)); background = rounded(card, 15, Color.rgb(45,53,80))
    }
    private fun actionButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(dp(12), dp(15), dp(12), dp(15)); background = rounded(accent, 16); setOnClickListener { action() }
    }
    private fun cycleTheme() {
        accent = when (accent) { Color.rgb(139,67,255) -> Color.rgb(15,150,255); Color.rgb(15,150,255) -> Color.rgb(245,55,100); else -> Color.rgb(139,67,255) }
        showHome()
    }

    private fun searchManga() {
        val query = nameInput.text.toString().trim()
        val story = storyInput.text.toString().trim()
        if (query.isBlank() && story.isBlank() && selectedGenres.isEmpty()) { status.text = "عنوان، توضیح یا حداقل یک ژانر وارد/انتخاب کن."; return }
        base("مانهواهای پیدا شده")
        content.addView(text("نتایج تصویری", 18f, Color.WHITE, true), params(6))
        content.addView(text("برای جست‌وجوی دقیق‌تر، عنوان انگلیسی معمولاً نتیجه‌های بهتری می‌دهد.", 13f, Color.LTGRAY), params(12))
        resultsBox = content
        val loading = text("در حال دریافت جلدها…", 15f, Color.LTGRAY).apply { gravity = Gravity.CENTER; setPadding(0,dp(28),0,dp(28)) }
        content.addView(loading, params())
        val q = listOf(query, story, selectedGenres.joinToString(" ")).filter { it.isNotBlank() }.joinToString(" ")
        worker.execute {
            try {
                val safe = q.replace("\"", "").replace("\\", " ")
                val gql = "query { Page(page:1, perPage:18) { media(search: \"$safe\", type:MANGA, sort:POPULARITY_DESC) { id title { romaji english native } coverImage { large } description(asHtml:false) siteUrl genres status } } }"
                val graphql = JSONObject().put("query", gql).toString()
                val conn = URL("https://graphql.anilist.co").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"; conn.connectTimeout = 12000; conn.readTimeout = 12000; conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(graphql.toByteArray(Charsets.UTF_8)) }
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val media = JSONObject(response).getJSONObject("data").getJSONObject("Page").getJSONArray("media")
                runOnUiThread {
                    content.removeView(loading)
                    if (media.length() == 0) content.addView(text("چیزی پیدا نشد. عنوان انگلیسی را امتحان کن یا لینک‌های وب را ببین.", 14f, Color.LTGRAY), params())
                    for (i in 0 until media.length()) addMangaCard(media.getJSONObject(i))
                    content.addView(actionButton("⌕  نمایش لینک‌های بیشتر (داخل برنامه)") { openInternalSearch(q) }, params(10))
                    content.addView(actionButton("✦  جست‌وجوی تازه") { showHome() }, params())
                }
            } catch (e: Exception) {
                runOnUiThread {
                    content.removeView(loading)
                    content.addView(text("دریافت فهرست مانهوا ناموفق بود. اینترنت را بررسی کن یا لینک‌های وب را باز کن.", 14f, Color.rgb(255,180,190)), params())
                    content.addView(actionButton("⌕  نمایش لینک‌های بیشتر (داخل برنامه)") { openInternalSearch(q) }, params())
                }
            }
        }
    }

    private fun addMangaCard(item: JSONObject) {
        val titleObj = item.optJSONObject("title") ?: JSONObject()
        val title = titleObj.optString("english").takeIf { it.isNotBlank() && it != "null" } ?: titleObj.optString("romaji", "بدون عنوان")
        val cover = item.optJSONObject("coverImage")?.optString("large") ?: ""
        val url = item.optString("siteUrl")
        val genresArr = item.optJSONArray("genres")
        val genresText = if (genresArr == null) "مانهوا" else (0 until minOf(3, genresArr.length())).joinToString(" • ") { genresArr.optString(it) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10),dp(10),dp(10),dp(10)); background = rounded(card, 16, Color.rgb(42,50,80)) }
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(Color.DKGRAY, 12) }
        row.addView(img, LinearLayout.LayoutParams(dp(92), dp(122)))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10),0,dp(4),0) }
        info.addView(text(title, 15f, Color.WHITE, true), params(5))
        info.addView(text(genresText, 11f, Color.rgb(177,160,220)), params(5))
        val desc = item.optString("description").replace(Regex("<[^>]*>"), " ").replace(Regex("\\s+"), " ").take(110)
        info.addView(text(if (desc.isBlank() || desc == "null") "برای جزئیات و لینک‌های رسمی باز کن." else desc, 12f, Color.rgb(190,198,220)).apply { maxLines = 3; ellipsize = TextUtils.TruncateAt.END }, params(8))
        info.addView(actionButton("اطلاعات و لینک‌ها  ↗") { if (url.startsWith("https://")) openInternalSearch(url) else openInternalSearch(title) }, params(0))
        row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(row, params(10))
        if (cover.startsWith("http")) worker.execute {
            try {
                val c = URL(cover).openConnection(); c.connectTimeout = 8000; c.readTimeout = 8000
                val bitmap = BitmapFactory.decodeStream(c.getInputStream())
                runOnUiThread { img.setImageBitmap(bitmap) }
            } catch (_: Exception) {}
        }
    }

    private fun openInternalSearch(query: String) {
        base("لینک‌های مرتبط")
        content.addView(text("این صفحه داخل Manhwa Hunter باز می‌شود؛ برای برگشت از دکمهٔ بالای صفحه استفاده کن.", 13f, Color.LTGRAY), params(8))
        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            if (query.startsWith("https://")) loadUrl(query) else loadUrl("https://duckduckgo.com/?q=" + Uri.encode("$query manhwa read official links"))
        }
        content.addView(web, LinearLayout.LayoutParams(-1, dp(560)))
    }
}
