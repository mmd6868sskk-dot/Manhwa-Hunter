package com.manhwahunter.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private var accent = Color.rgb(154, 86, 255)
    private lateinit var root: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(18))
            setBackgroundColor(Color.rgb(18, 18, 26))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(12))
        }
        scroll.addView(content)
        root.addView(scroll, ViewGroup.LayoutParams(-1, -1))

        val title = TextView(this).apply {
            text = "MANHWA HUNTER"
            textSize = 26f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        content.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "مانهواهای موردعلاقه‌ات را پیدا کن"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(20))
        }
        content.addView(subtitle, matchWrap())

        val nameInput = edit("اسم مانهوا را وارد کن")
        content.addView(label("جست‌وجو بر اساس عنوان"))
        content.addView(nameInput, matchWrap())

        val genreInput = edit("مثلاً سیستمی، کیمیاگری، فانتزی")
        content.addView(label("ژانر"))
        content.addView(genreInput, matchWrap())

        val storyInput = edit("خلاصه‌ای از داستان (اختیاری)")
        content.addView(label("توضیح داستان"))
        content.addView(storyInput, matchWrap())

        val sourceTitle = label("منابع موردنظر")
        content.addView(sourceTitle)
        val web = check("وب‌سایت‌ها")
        val telegramPublic = check("کانال‌های عمومی تلگرام")
        val telegramJoined = check("کانال‌های تلگرام با اتصال حساب (بعداً)")
        val rubika = check("روبیکا (بعداً)")
        web.isChecked = true
        telegramPublic.isChecked = true
        listOf(web, telegramPublic, telegramJoined, rubika).forEach {
            content.addView(it, matchWrap())
        }

        val themes = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("بنفش تیره", "قرمز تیره", "آبی اقیانوسی", "سبز نئونی", "روشن")
            )
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    accent = when (position) {
                        1 -> Color.rgb(255, 70, 90)
                        2 -> Color.rgb(40, 170, 220)
                        3 -> Color.rgb(80, 220, 110)
                        4 -> Color.rgb(120, 90, 200)
                        else -> Color.rgb(154, 86, 255)
                    }
                }
            }
        }
        content.addView(label("رنگ برنامه"))
        content.addView(themes, matchWrap())

        val search = Button(this).apply {
            text = "آماده‌سازی جست‌وجو"
            setTextColor(Color.WHITE)
            setBackgroundColor(accent)
            setOnClickListener {
                val parts = mutableListOf<String>()
                if (nameInput.text.isNotBlank()) parts.add("عنوان: ${nameInput.text}")
                if (genreInput.text.isNotBlank()) parts.add("ژانر: ${genreInput.text}")
                if (storyInput.text.isNotBlank()) parts.add("داستان: ${storyInput.text}")
                if (parts.isEmpty()) {
                    status.text = "اول عنوان، ژانر یا توضیح داستان را وارد کن."
                } else {
                    status.text = "عبارت جست‌وجو آماده شد:\n" + parts.joinToString("\n") +
                        "\n\nاین نسخهٔ اولیه است؛ هنوز موتور جست‌وجوی واقعی به منابع وصل نشده."
                }
            }
        }
        content.addView(search, matchWrap())

        status = TextView(this).apply {
            text = "نسخهٔ آزمایشی ۰٫۱ — جست‌وجوی واقعی و اتصال حساب‌ها هنوز فعال نیست."
            textSize = 14f
            setTextColor(Color.rgb(225, 220, 240))
            setPadding(dp(12), dp(14), dp(12), dp(14))
        }
        content.addView(status, matchWrap())

        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply {
        bottomMargin = dp(8)
    }

    private fun label(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 14f
        setTextColor(Color.rgb(205, 190, 235))
        setPadding(0, dp(8), 0, dp(3))
    }

    private fun edit(hintText: String) = EditText(this).apply {
        hint = hintText
        textSize = 15f
        setSingleLine(false)
        setTextColor(Color.WHITE)
        setHintTextColor(Color.GRAY)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setBackgroundColor(Color.rgb(39, 37, 51))
    }

    private fun check(textValue: String) = CheckBox(this).apply {
        text = textValue
        textSize = 14f
        setTextColor(Color.WHITE)
        buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(190, 150, 255))
    }
}
