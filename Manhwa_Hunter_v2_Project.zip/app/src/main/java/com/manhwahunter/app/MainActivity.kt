package com.manhwahunter.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private var accent = Color.rgb(154, 86, 255)
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var nameInput: EditText
    private lateinit var genreInput: EditText
    private lateinit var storyInput: EditText
    private lateinit var web: CheckBox
    private lateinit var telegramPublic: CheckBox
    private lateinit var rubika: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(18))
            setBackgroundColor(Color.rgb(18, 18, 26))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(12))
        }
        scroll.addView(content)
        root.addView(scroll, ViewGroup.LayoutParams(-1, -1))

        val title = TextView(this).apply {
            text = "MANHWA HUNTER"
            textSize = 26f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        content.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "مانهواهای موردعلاقه‌ات را پیدا کن"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(20))
        }
        content.addView(subtitle, matchWrap())

        nameInput = edit("اسم مانهوا را وارد کن")
        content.addView(label("جست‌وجو بر اساس عنوان"))
        content.addView(nameInput, matchWrap())

        genreInput = edit("مثلاً سیستمی، کیمیاگری، فانتزی")
        content.addView(label("ژانر (اختیاری)"))
        content.addView(genreInput, matchWrap())

        storyInput = edit("خلاصه‌ای از داستان (اختیاری)")
        content.addView(label("توضیح داستان (اختیاری)"))
        content.addView(storyInput, matchWrap())

        content.addView(label("منابع جست‌وجو"))
        web = check("وب‌سایت‌ها و موتورهای جست‌وجو").apply { isChecked = true }
        telegramPublic = check("صفحه‌ها و کانال‌های عمومی تلگرام").apply { isChecked = true }
        rubika = check("نتایج عمومی مرتبط با روبیکا")
        listOf(web, telegramPublic, rubika).forEach { content.addView(it, matchWrap()) }

        val themes = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("بنفش تیره", "قرمز تیره", "آبی اقیانوسی", "سبز نئونی", "روشن")
            )
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    accent = when (position) {
                        1 -> Color.rgb(255, 70, 90)
                        2 -> Color.rgb(40, 170, 220)
                        3 -> Color.rgb(80, 220, 110)
                        4 -> Color.rgb(120, 90, 200)
                        else -> Color.rgb(154, 86, 255)
                    }
                }
            }
        }
        content.addView(label("رنگ برنامه"))
        content.addView(themes, matchWrap())

        val search = Button(this).apply {
            text = "جست‌وجو در منابع انتخاب‌شده"
            setTextColor(Color.WHITE)
            setBackgroundColor(accent)
            setOnClickListener { launchSearches() }
        }
        content.addView(search, matchWrap())

        val latest = Button(this).apply {
            text = "پیدا کردن چپترهای جدید"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(70, 65, 90))
            setOnClickListener {
                val titleText = nameInput.text.toString().trim()
                if (titleText.isBlank()) {
                    status.text = "برای جست‌وجوی چپترهای جدید، اول اسم مانهوا را بنویس."
                } else {
                    openSearch("https://www.google.com/search?q=" + Uri.encode("\"$titleText\" latest chapter update"))
                }
            }
        }
        content.addView(latest, matchWrap())

        status = TextView(this).apply {
            text = "نسخهٔ ۰٫۲ — جست‌وجو از طریق مرورگر باز می‌شود. اتصال مستقیم به حساب تلگرام/روبیکا و جمع‌آوری خودکار نتایج هنوز فعال نیست."
            textSize = 14f
            setTextColor(Color.rgb(225, 220, 240))
            setPadding(dp(12), dp(14), dp(12), dp(14))
        }
        content.addView(status, matchWrap())
        setContentView(root)
    }

    private fun launchSearches() {
        val title = nameInput.text.toString().trim()
        val genre = genreInput.text.toString().trim()
        val story = storyInput.text.toString().trim()
        if (title.isBlank() && genre.isBlank() && story.isBlank()) {
            status.text = "اول عنوان، ژانر یا توضیح داستان را وارد کن."
            return
        }

        val base = listOf(title, genre, story).filter { it.isNotBlank() }.joinToString(" ")
        val queries = mutableListOf<Pair<String, String>>()
        if (web.isChecked) {
            queries.add("جست‌وجوی وب" to ("https://www.google.com/search?q=" + Uri.encode("$base مانهوا ترجمه فارسی")))
        }
        if (telegramPublic.isChecked) {
            queries.add("تلگرام عمومی" to ("https://www.google.com/search?q=" + Uri.encode("site:t.me $base مانهوا فارسی")))
        }
        if (rubika.isChecked) {
            queries.add("روبیکا" to ("https://www.google.com/search?q=" + Uri.encode("site:rubika.ir $base مانهوا")))
        }

        if (queries.isEmpty()) {
            status.text = "حداقل یک منبع را انتخاب کن."
            return
        }
        status.text = "در حال باز کردن ${queries.size} جست‌وجو در مرورگر…\nتوجه: این‌ها نتایج عمومی وب هستند؛ همهٔ کانال‌ها یا محتوای خصوصی قابل پیدا کردن نیستند."
        queries.forEachIndexed { index, item ->
            // Launch one at a time; the browser may group or foreground tabs depending on device settings.
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.second)))
            } catch (_: Exception) {
                status.text = "مرورگری برای باز کردن جست‌وجو پیدا نشد."
            }
        }
    }

    private fun openSearch(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            status.text = "مرورگری برای باز کردن جست‌وجو پیدا نشد."
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply {
        bottomMargin = dp(8)
    }

    private fun label(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 14f
        setTextColor(Color.rgb(205, 190, 235))
        setPadding(0, dp(8), 0, dp(3))
    }

    private fun edit(hintText: String) = EditText(this).apply {
        hint = hintText
        textSize = 15f
        setSingleLine(false)
        setTextColor(Color.WHITE)
        setHintTextColor(Color.GRAY)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setBackgroundColor(Color.rgb(39, 37, 51))
    }

    private fun check(textValue: String) = CheckBox(this).apply {
        text = textValue
        textSize = 14f
        setTextColor(Color.WHITE)
        buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(190, 150, 255))
    }
}
