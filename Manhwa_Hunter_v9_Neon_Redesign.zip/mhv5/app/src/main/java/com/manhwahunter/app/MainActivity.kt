package com.manhwahunter.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.TextUtils
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 10, 20)
    private val card = Color.rgb(17, 23, 42)
    private var accent = Color.rgb(185, 25, 245)
    private val neonPink = Color.rgb(255, 25, 125)
    private val deepPurple = Color.rgb(35, 8, 72)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private lateinit var nameInput: EditText
    private lateinit var storyInput: EditText
    private lateinit var resultsBox: LinearLayout
    private val selectedGenres = linkedSetOf<String>()
    private var searchPage = 1
    private var lastSearchQuery = ""
    private val preferredSites = listOf("مانسیت", "مانهوا تاور", "مانگیت", "مانگا آپ", "بوک خان", "مانهوا چی", "مانگاریوم", "مانگا باز")
    private val worker = Executors.newFixedThreadPool(4)
    private val genres = listOf("اکشن", "فانتزی", "ماجراجویی", "سیستمی", "تناسخی", "عاشقانه", "کمدی", "ترسناک", "مدرسه‌ای", "هنرهای رزمی", "دانش‌آموزی", "درام")
    private val genreButtons = mutableMapOf<String, TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 3, 12)
        window.navigationBarColor = Color.rgb(5, 3, 12)
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 16, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun text(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun params(bottom: Int = 10) = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom) }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(6, 5, 15))
            setPadding(dp(16), dp(10), dp(16), dp(12))
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        val back = text("‹", 34f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; background = rounded(Color.rgb(19, 12, 32), 15, Color.rgb(94, 30, 130))
            setOnClickListener { showHome() }
        }
        top.addView(back, LinearLayout.LayoutParams(dp(42), dp(44)).apply { rightMargin = dp(10) })
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(text(title, 19f, Color.WHITE, true))
        titleBox.addView(text("NEON • MANHWA • UNIVERSE", 9f, Color.rgb(207, 106, 255), true))
        top.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        val crown = text("♛", 27f, neonPink, true).apply {
            gravity = Gravity.CENTER; background = rounded(Color.rgb(28, 9, 42), 15, accent)
        }
        top.addView(crown, LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(top, params(14))
        val divider = View(this).apply { background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.TRANSPARENT, neonPink, accent, Color.TRANSPARENT)) }
        root.addView(divider, LinearLayout.LayoutParams(-1, dp(1)).apply { bottomMargin = dp(10) })
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0,0,0,dp(18)) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showHome() {
        base("MANHWA HUNTER")
        // Featured banner styled after the supplied Manhwa Hunter reference.
        val heroFrame = FrameLayout(this).apply {
            background = rounded(Color.BLACK, 20, neonPink)
            clipToOutline = true
        }
        val hero = ImageView(this).apply {
            setImageResource(com.manhwahunter.app.R.drawable.anime_banner)
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.82f
        }
        heroFrame.addView(hero, FrameLayout.LayoutParams(-1, -1))
        val shade = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                intArrayOf(Color.rgb(7, 2, 18), Color.argb(45, 110, 0, 180), Color.TRANSPARENT))
        }
        heroFrame.addView(shade, FrameLayout.LayoutParams(-1, -1))
        val heroText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM
            setPadding(dp(16), dp(12), dp(16), dp(14))
        }
        heroText.addView(text("Solo Leveling", 20f, Color.WHITE, true), params(3))
        heroText.addView(text("قوی‌ترین شکارچی؛ شروع یک ماجراجویی جدید", 13f, Color.rgb(245,225,255)), params(8))
        heroText.addView(actionButton("مشاهده  ›") { nameInput.setText("Solo Leveling"); searchManga() },
            LinearLayout.LayoutParams(dp(115), -2))
        heroFrame.addView(heroText, FrameLayout.LayoutParams(-1, -1))
        content.addView(heroFrame, LinearLayout.LayoutParams(-1, dp(220)).apply { bottomMargin = dp(18) })
        val intro = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(Color.rgb(17, 9, 29), 14, Color.rgb(100, 25, 130))
        }
        intro.addView(text("✦  دنیای مانهوا، با حال‌وهوای نئونی", 13f, Color.rgb(242, 218, 255), true), LinearLayout.LayoutParams(0, -2, 1f))
        intro.addView(text("LIVE", 10f, neonPink, true))
        content.addView(intro, params(16))

        content.addView(text("دسترسی سریع  ✦", 16f, Color.WHITE, true), params(8))
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        quick.addView(actionButton("🔵  تلگرام") { openLink("https://t.me/s/manhwa") },
            LinearLayout.LayoutParams(0, dp(58), 1f).apply { setMargins(0,0,dp(5),0) })
        quick.addView(actionButton("🟢  روبیکا") { openLink("https://rubika.ir") },
            LinearLayout.LayoutParams(0, dp(58), 1f).apply { setMargins(dp(5),0,0,0) })
        content.addView(quick, params(8))

        content.addView(text("دسته‌بندی ژانرها  ›", 16f, Color.WHITE, true), params(8))
        val genrePreview = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("⚔\nاکشن", "🐉\nفانتزی", "♨\nماجراجویی", "♥\nعاشقانه", "☠\nترسناک").forEach { label ->
            val parts = label.split("\n")
            val b = text(parts.joinToString("\n"), 12f, Color.rgb(245,205,250), true).apply {
                gravity = Gravity.CENTER
                background = rounded(Color.rgb(21, 10, 35), 18, if (parts.last() == "اکشن" || parts.last() == "عاشقانه") neonPink else Color.rgb(112, 46, 180))
                setPadding(dp(8), dp(10), dp(8), dp(10))
                setOnClickListener {
                    val g = parts.last()
                    if (genres.contains(g)) {
                        selectedGenres.add(g); showHome()
                    } else {
                        content.post { nameInput.requestFocus() }
                    }
                }
            }
            genrePreview.addView(b, LinearLayout.LayoutParams(0, dp(68), 1f).apply { setMargins(dp(2),0,dp(2),0) })
        }
        content.addView(genrePreview, params(14))

        content.addView(text("محبوب‌ترین مانهواها  ›", 16f, Color.WHITE, true), params(8))
        val popular = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val popularLoading = text("در حال دریافت جلد واقعی مانهواها…", 12f, Color.rgb(210, 180, 240)).apply {
            gravity = Gravity.CENTER; background = rounded(Color.rgb(18, 7, 31), 12, neonPink); setPadding(dp(8), dp(18), dp(8), dp(18))
        }
        popular.addView(popularLoading, LinearLayout.LayoutParams(-1, dp(60)))
        content.addView(popular, params(14))
        loadPopularManga(popular)

        content.addView(actionButton("🌐  سایت‌های پیشنهادی برای جست‌وجو") { showPreferredSites("") }, params(8))

        content.addView(text("جست‌وجوی مانهوا", 16f, Color.WHITE, true), params(8))
        nameInput = input("نام مانهوا را وارد کن…")
        content.addView(nameInput, params(8))
        storyInput = input("توضیح داستان (اختیاری)")
        content.addView(storyInput, params(8))

        content.addView(text("همهٔ ژانرها  •  برای انتخاب روی ژانر بزن", 14f, Color.WHITE, true), params(6))
        genreButtons.clear()
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        genres.chunked(3).forEach { rowItems ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowItems.forEach { g ->
                val b = text("✦  $g", 12f, Color.rgb(220,220,240), true).apply {
                    gravity = Gravity.CENTER; setPadding(dp(3), dp(10), dp(3), dp(10))
                    background = rounded(Color.rgb(15, 12, 29), 14, Color.rgb(62, 39, 91))
                    setOnClickListener {
                        if (selectedGenres.contains(g)) selectedGenres.remove(g) else selectedGenres.add(g)
                        updateGenreButtons()
                    }
                }
                genreButtons[g] = b
                row.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            grid.addView(row, params(2))
        }
        content.addView(grid, params(8))
        content.addView(actionButton("⌕  جست‌وجو") { searchManga() }, params(8))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(6), dp(4), dp(6))
            background = rounded(Color.rgb(12,9,24), 18, Color.rgb(95,30,135))
        }
        listOf("⌂\nخانه", "▦\nدسته‌بندی", "♡\nعلاقه‌مندی", "✈\nتلگرام", "◈\nروبیکا").forEachIndexed { index, label ->
            val b = text(label, 11f, if (index == 0) Color.rgb(220,70,255) else Color.rgb(200,190,225), true).apply {
                gravity = Gravity.CENTER
                setOnClickListener {
                    when(index) {
                        0 -> showHome()
                        1 -> { content.post { nameInput.requestFocus() } }
                        2 -> Toast.makeText(this@MainActivity, "برای ذخیرهٔ علاقه‌مندی‌ها، ابتدا نتیجه‌ای را انتخاب کن.", Toast.LENGTH_SHORT).show()
                        3 -> openLink("https://t.me/s/manhwa")
                        4 -> openLink("https://rubika.ir")
                    }
                }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        content.addView(nav, params(10))
        status = text("نتایج جست‌وجو با تصویر جلد و لینک داخل برنامه نمایش داده می‌شوند.", 12f, Color.rgb(180,190,215)).apply {
            setPadding(dp(10),dp(8),dp(10),dp(8)); background = rounded(card, 12)
        }
        content.addView(status, params(8))
    }

    private fun loadPopularManga(container: LinearLayout) {
        worker.execute {
            try {
                val gql = "query { Page(page:1, perPage:4) { media(type:MANGA, sort:POPULARITY_DESC, isAdult:false) { title { romaji english } coverImage { large } siteUrl genres } } }"
                val body = JSONObject().put("query", gql).toString()
                val conn = URL("https://graphql.anilist.co").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"; conn.connectTimeout = 12000; conn.readTimeout = 12000; conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val media = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                    .getJSONObject("data").getJSONObject("Page").getJSONArray("media")
                runOnUiThread {
                    container.removeAllViews()
                    if (media.length() == 0) {
                        container.addView(text("جلدها در دسترس نیست؛ اینترنت را بررسی کن.", 12f, Color.LTGRAY))
                        return@runOnUiThread
                    }
                    for (i in 0 until minOf(4, media.length())) {
                        val item = media.getJSONObject(i)
                        val titleObj = item.optJSONObject("title") ?: JSONObject()
                        val title = titleObj.optString("english").takeIf { it.isNotBlank() && it != "null" }
                            ?: titleObj.optString("romaji", "مانهوا")
                        val coverUrl = item.optJSONObject("coverImage")?.optString("large") ?: ""
                        val tile = LinearLayout(this).apply {
                            orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(4), dp(4), dp(4))
                            background = rounded(Color.rgb(13, 5, 25), 12, if (i % 2 == 0) neonPink else accent)
                            setOnClickListener { nameInput.setText(title); searchManga() }
                        }
                        val image = ImageView(this).apply {
                            scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(deepPurple, 9); clipToOutline = true
                        }
                        tile.addView(image, LinearLayout.LayoutParams(-1, dp(118)))
                        tile.addView(text(title, 10f, Color.WHITE, true).apply {
                            maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(dp(3), dp(5), dp(3), dp(3))
                        }, params(2))
                        container.addView(tile, LinearLayout.LayoutParams(0, dp(166), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
                        if (coverUrl.startsWith("http")) worker.execute {
                            try {
                                val c = URL(coverUrl).openConnection(); c.connectTimeout = 8000; c.readTimeout = 8000
                                val bitmap = BitmapFactory.decodeStream(c.getInputStream())
                                runOnUiThread { image.setImageBitmap(bitmap) }
                            } catch (_: Exception) { }
                        }
                    }
                }
            } catch (_: Exception) {
                runOnUiThread {
                    container.removeAllViews()
                    container.addView(text("برای نمایش جلدهای واقعی، اتصال اینترنت لازم است.", 12f, Color.rgb(220, 180, 240)))
                }
            }
        }
    }

    private fun updateGenreButtons() {
        genreButtons.forEach { (g, b) ->
            val chosen = selectedGenres.contains(g)
            b.text = (if (chosen) "✓  " else "✦  ") + g
            b.setTextColor(if (chosen) Color.WHITE else Color.rgb(220,220,240))
            b.background = rounded(if (chosen) accent else card, 15, if (chosen) Color.rgb(205,150,255) else Color.rgb(50,55,85))
        }
    }

    private fun input(hintText: String) = EditText(this).apply {
        hint = hintText; textSize = 15f; setTextColor(Color.WHITE); setHintTextColor(Color.rgb(135,145,170)); setPadding(dp(14), dp(12), dp(14), dp(12)); background = rounded(Color.rgb(13, 9, 27), 15, Color.rgb(90, 35, 115))
    }
    private fun actionButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setTextColor(Color.WHITE); setPadding(dp(12), dp(13), dp(12), dp(13))
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.rgb(117, 20, 190), Color.rgb(190, 22, 135))).apply {
            cornerRadius = dp(15).toFloat(); setStroke(dp(1), Color.rgb(244, 70, 190))
        }
        elevation = dp(2).toFloat()
        setOnClickListener { action() }
    }
    private fun cycleTheme() {
        accent = when (accent) { Color.rgb(139,67,255) -> Color.rgb(15,150,255); Color.rgb(15,150,255) -> Color.rgb(245,55,100); else -> Color.rgb(139,67,255) }
        showHome()
    }

    private fun searchManga() {
        val query = nameInput.text.toString().trim()
        val story = storyInput.text.toString().trim()
        if (query.isBlank() && story.isBlank() && selectedGenres.isEmpty()) {
            status.text = "اسم مانهوا یا ژانر را وارد کن."
            return
        }
        val q = listOf(query, story, selectedGenres.joinToString(" ")).filter { it.isNotBlank() }.joinToString(" ").trim()
        lastSearchQuery = q
        searchPage = 1
        showPreferredSites(q)
    }

    private fun addMangaCard(item: JSONObject) {
        val titleObj = item.optJSONObject("title") ?: JSONObject()
        val title = titleObj.optString("english").takeIf { it.isNotBlank() && it != "null" } ?: titleObj.optString("romaji", "بدون عنوان")
        val cover = item.optJSONObject("coverImage")?.optString("large") ?: ""
        val url = item.optString("siteUrl")
        val genresArr = item.optJSONArray("genres")
        val genresText = if (genresArr == null) "مانهوا" else (0 until minOf(3, genresArr.length())).joinToString(" • ") { genresArr.optString(it) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10),dp(10),dp(10),dp(10)); background = rounded(card, 16, Color.rgb(42,50,80)) }
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(Color.DKGRAY, 12) }
        row.addView(img, LinearLayout.LayoutParams(dp(92), dp(122)))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10),0,dp(4),0) }
        info.addView(text(title, 15f, Color.WHITE, true), params(5))
        info.addView(text(genresText, 11f, Color.rgb(177,160,220)), params(5))
        val desc = item.optString("description").replace(Regex("<[^>]*>"), " ").replace(Regex("\\s+"), " ").take(110)
        info.addView(text(if (desc.isBlank() || desc == "null") "برای جزئیات و لینک‌های رسمی باز کن." else desc, 12f, Color.rgb(190,198,220)).apply { maxLines = 3; ellipsize = TextUtils.TruncateAt.END }, params(8))
        info.addView(actionButton("📖 ثبت آخرین چپتر") { showChapterTracker(title) }, params(4))
        info.addView(actionButton("اطلاعات و لینک‌ها  ↗") { showMangaDetails(title, desc, url) }, params(0))
        row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(row, params(10))
        if (cover.startsWith("http")) worker.execute {
            try {
                val c = URL(cover).openConnection(); c.connectTimeout = 8000; c.readTimeout = 8000
                val bitmap = BitmapFactory.decodeStream(c.getInputStream())
                runOnUiThread { img.setImageBitmap(bitmap) }
            } catch (_: Exception) {}
        }
    }

    private fun searchMangaFromSavedQuery() {
        showPreferredSites(lastSearchQuery)
    }

    private fun showChapterTracker(title: String) {
        base("آخرین چپتر خوانده‌شده")
        content.addView(text(title, 20f, Color.WHITE, true), params(12))
        val prefs = getSharedPreferences("reading_progress", MODE_PRIVATE)
        val key = "chapter_" + title
        val field = input("شمارهٔ چپتر، مثلاً 125").apply { setText(prefs.getString(key, "") ?: ""); inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL }
        content.addView(field, params(10))
        content.addView(actionButton("ذخیرهٔ چپتر") { val value = field.text.toString().trim(); prefs.edit().putString(key, value).apply(); Toast.makeText(this, if (value.isBlank()) "شمارهٔ چپتر پاک شد" else "چپتر $value برای $title ذخیره شد", Toast.LENGTH_SHORT).show() }, params(8))
        content.addView(text("چپتر ذخیره‌شده: ${prefs.getString(key, "ثبت نشده")}", 14f, Color.rgb(235,180,255)), params(8))
    }

    private fun showMangaDetails(title: String, description: String, sourceUrl: String) {
        base(title)
        content.addView(text(description.ifBlank { "توضیحی برای این عنوان موجود نیست." }, 14f, Color.rgb(220,210,235)), params(12))
        content.addView(actionButton("📖 ثبت آخرین چپتر خوانده‌شده") { showChapterTracker(title) }, params(8))
        if (sourceUrl.startsWith("https://")) content.addView(actionButton("اطلاعات اصلی مانهوا ↗") { openLink(sourceUrl) }, params(8))
        content.addView(actionButton("جست‌وجو در ۸ سایت فارسی انتخابی تو") { showPreferredSites(title) }, params(8))
    }

    private data class PreferredSite(val name: String, val home: String, val searchUrl: (String) -> String, val verified: Boolean = true)

    private fun preferredSiteList(): List<PreferredSite> = listOf(
        PreferredSite("مانسیت", "https://maneast.fun", { q -> "https://maneast.fun/search?query=" + Uri.encode(q) }),
        PreferredSite("مانهوا تاور", "https://manhwa-tower.ir", { q -> "https://manhwa-tower.ir/?s=" + Uri.encode(q) }),
        PreferredSite("مانگیت", "https://mangate.ir", { q -> "https://mangate.ir/?s=" + Uri.encode(q) }),
        PreferredSite("مانگا آپ", "https://mangaup.ir", { q -> "https://mangaup.ir/?s=" + Uri.encode(q) }),
        PreferredSite("بوک خان", "https://book-khan.ir", { q -> "https://book-khan.ir/?s=" + Uri.encode(q) }),
        // These two names did not resolve to a confidently verified official domain.
        PreferredSite("مانهوا چی", "", { _ -> "" }, false),
        PreferredSite("مانگاریوم", "https://mangariom.top", { q -> "https://mangariom.top/?s=" + Uri.encode(q) }),
        PreferredSite("مانگا باز", "", { _ -> "" }, false)
    )

    private fun showPreferredSites(query: String, iranianOnly: Boolean? = null) {
        base(if (query.isBlank()) "سایت‌های پیشنهادی تو" else "جست‌وجوی فارسی: $query")
        content.addView(text("نتایج فقط از سایت‌های فارسی انتخابی تو باز می‌شوند؛ هیچ جست‌وجوی گوگل یا سایت خارجی در این فهرست نیست.", 13f, Color.rgb(220,205,245)), params(12))
        if (query.isNotBlank()) {
            content.addView(text("عبارت جست‌وجو: $query", 15f, Color.WHITE, true), params(10))
        } else {
            content.addView(text("برای جست‌وجو، نام مانهوا را وارد کن و یکی از سایت‌ها را بزن.", 13f, Color.LTGRAY), params(10))
        }
        preferredSiteList().forEachIndexed { index, site ->
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = rounded(Color.rgb(16, 9, 28), 18, if (index % 2 == 0) neonPink else Color.rgb(121, 55, 220))
            }
            box.addView(text("${index + 1}. ${site.name}", 16f, Color.WHITE, true), params(4))
            val description = when {
                !site.verified -> "برای جست‌وجوی مستقیم، آدرس رسمی این سایت هنوز تأیید نشده است."
                query.isBlank() -> site.home
                else -> "جست‌وجوی «$query» در همین سایت"
            }
            box.addView(text(description, 12f, Color.rgb(195,180,220)), params(7))
            box.addView(actionButton(if (!site.verified) "ثبت آدرس رسمی سایت" else if (query.isBlank()) "باز کردن سایت ↗" else "جست‌وجو در ${site.name} ↗") {
                if (!site.verified) {
                    Toast.makeText(this, "آدرس دقیق و رسمی ${site.name} را بفرست تا جست‌وجوی مستقیمش را اضافه کنم.", Toast.LENGTH_LONG).show()
                } else {
                    val url = if (query.isBlank()) site.home else site.searchUrl(query)
                    openWebsiteInsideApp(url, site.name)
                }
            }, params(0))
            content.addView(box, params(9))
        }
        content.addView(actionButton("← بازگشت به خانه") { showHome() }, params(8))
    }

    private fun openInternalSearch(query: String) {
        showPreferredSites(query)
    }

    private fun openWebsiteInsideApp(url: String, title: String) {
        if (url.isBlank()) return
        base(title)
        val web = android.webkit.WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            webViewClient = android.webkit.WebViewClient()
            loadUrl(url)
        }
        content.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        content.addView(actionButton("← برگشت به نتایج سایت‌ها") { showPreferredSites(lastSearchQuery) }, params(0))
    }

    private fun openLink(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { Toast.makeText(this, "لینک در دسترس نیست.", Toast.LENGTH_SHORT).show() }
    }

    private fun showLinkDirectory(title: String, links: List<Pair<String, String>>) {
        base(title)
        content.addView(text("بدون مرورگر داخلی؛ عنوان و لینک‌ها اینجا نمایش داده می‌شوند. برای رفتن به لینک، روی دکمه بزن.", 13f, Color.rgb(220,205,245)), params(12))
        links.forEachIndexed { index, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(14), dp(14), dp(14))
                background = rounded(Color.argb(220, 17, 13, 34), 18, if (index % 2 == 0) accent else Color.rgb(220, 45, 120))
            }
            row.addView(text("✦  ${item.second}", 15f, Color.WHITE, true), params(6))
            row.addView(text(item.first, 11f, Color.rgb(205,190,230)), params(8))
            row.addView(actionButton("باز کردن لینک  ↗") { openLink(item.first) }, params(0))
            content.addView(row, params(10))
        }
        content.addView(actionButton("✈ تلگرام") { openLink("https://t.me/s/manhwa") }, params(8))
        content.addView(actionButton("◈ روبیکا") { openLink("https://rubika.ir") }, params(8))
    }
}
